
// Service Disabled
export const fetchHistoryData = async () => {
    return [];
};
